#!/usr/bin/env python3
import socket
import threading
import time
import tkinter as tk
from tkinter import messagebox, scrolledtext

USER_DATABASE = {}


class CatChatApp:

  def __init__(self, root):
    self.root = root
    self.root.title("CatChat 🐾 - Linux Edition")
    self.root.geometry("480x640")
    self.root.configure(bg="#FFF0F5")

    self.sock = None
    self.server_sock = None
    self.running = True
    self.my_name = ""

    self.show_home_screen()

  def clear_window(self):
    for widget in self.root.winfo_children():
      widget.destroy()

  def show_home_screen(self):
    self.disconnect_socket()
    self.clear_window()

    tk.Label(
        self.root,
        text="🐾 CatChat 🐾",
        font=("Helvetica", 22, "bold"),
        bg="#FFF0F5",
        fg="#D87093",
    ).pack(pady=30)
    tk.Label(
        self.root,
        text="The purr-fect way to chat with friends\non local Wi-Fi!",
        font=("Helvetica", 11),
        bg="#FFF0F5",
        fg="#666666",
        justify=tk.CENTER,
    ).pack(pady=10)

    btn_frame = tk.Frame(self.root, bg="#FFF0F5")
    btn_frame.pack(pady=30)

    tk.Button(
        btn_frame,
        text="🏠 Host a Litter Box (Server)",
        font=("Helvetica", 12, "bold"),
        bg="#FFB6C1",
        fg="#FFFFFF",
        relief=tk.FLAT,
        command=self.show_host_screen,
        padx=15,
        pady=10,
    ).pack(pady=10, fill=tk.X)
    tk.Button(
        btn_frame,
        text="🐈 Join a Friend Room",
        font=("Helvetica", 12, "bold"),
        bg="#FFC0CB",
        fg="#FFFFFF",
        relief=tk.FLAT,
        command=self.show_join_screen,
        padx=15,
        pady=10,
    ).pack(pady=10, fill=tk.X)

  def show_host_screen(self):
    self.clear_window()
    tk.Label(
        self.root,
        text="🐾 Host CatChat 🐾",
        font=("Helvetica", 18, "bold"),
        bg="#FFF0F5",
        fg="#D87093",
    ).pack(pady=20)

    try:
      s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
      s.connect(("8.8.8.8", 80))
      local_ip = s.getsockname()[0]
      s.close()
    except:
      local_ip = "127.0.0.1"

    tk.Label(
        self.root,
        text=f"Your IP for friends to connect:\n{local_ip}",
        font=("Helvetica", 11, "bold"),
        bg="#FFF0F5",
        fg="#333333",
    ).pack(pady=10)

    form = tk.Frame(self.root, bg="#FFF0F5")
    form.pack(pady=10)

    tk.Label(
        form, text="Host Username:", font=("Helvetica", 11), bg="#FFF0F5"
    ).pack(anchor="w")
    self.host_name_entry = tk.Entry(form, font=("Helvetica", 12), relief=tk.FLAT)
    self.host_name_entry.pack(ipady=5, fill=tk.X, pady=5)
    self.host_name_entry.insert(0, "Lena_Cat")

    tk.Label(
        form, text="Host Password:", font=("Helvetica", 11), bg="#FFF0F5"
    ).pack(anchor="w")
    self.host_pass_entry = tk.Entry(
        form, font=("Helvetica", 12), relief=tk.FLAT, show="*"
    )
    self.host_pass_entry.pack(ipady=5, fill=tk.X, pady=5)

    tk.Button(
        form,
        text="Start Hosting & Login 🐟",
        font=("Helvetica", 11, "bold"),
        bg="#FFB6C1",
        fg="#FFFFFF",
        relief=tk.FLAT,
        command=lambda: self.start_host(local_ip),
        padx=15,
        pady=8,
    ).pack(pady=15)
    tk.Button(
        self.root,
        text="Back",
        font=("Helvetica", 10),
        bg="#E0E0E0",
        relief=tk.FLAT,
        command=self.show_home_screen,
    ).pack()

  def show_join_screen(self):
    self.clear_window()
    tk.Label(
        self.root,
        text="🐾 CatChat Login / Register 🐾",
        font=("Helvetica", 18, "bold"),
        bg="#FFF0F5",
        fg="#D87093",
    ).pack(pady=20)

    form = tk.Frame(self.root, bg="#FFF0F5")
    form.pack(pady=10)

    tk.Label(
        form, text="Friend Host IP:", font=("Helvetica", 11), bg="#FFF0F5"
    ).pack(anchor="w")
    self.ip_entry = tk.Entry(form, font=("Helvetica", 12), relief=tk.FLAT)
    self.ip_entry.pack(ipady=5, fill=tk.X, pady=5)
    self.ip_entry.insert(0, "192.168.2.")

    tk.Label(
        form, text="Cat Username:", font=("Helvetica", 11), bg="#FFF0F5"
    ).pack(anchor="w")
    self.join_name_entry = tk.Entry(form, font=("Helvetica", 12), relief=tk.FLAT)
    self.join_name_entry.pack(ipady=5, fill=tk.X, pady=5)

    tk.Label(
        form, text="Password:", font=("Helvetica", 11), bg="#FFF0F5"
    ).pack(anchor="w")
    self.join_pass_entry = tk.Entry(
        form, font=("Helvetica", 12), relief=tk.FLAT, show="*"
    )
    self.join_pass_entry.pack(ipady=5, fill=tk.X, pady=5)

    btn_row = tk.Frame(form, bg="#FFF0F5")
    btn_row.pack(pady=15)

    tk.Button(
        btn_row,
        text="Login 🐾",
        font=("Helvetica", 11, "bold"),
        bg="#FFB6C1",
        fg="#FFFFFF",
        relief=tk.FLAT,
        command=lambda: self.authenticate("LOGIN"),
        padx=10,
        pady=8,
    ).pack(side=tk.LEFT, padx=5)
    tk.Button(
        btn_row,
        text="Create Account 🐈",
        font=("Helvetica", 11, "bold"),
        bg="#FFC0CB",
        fg="#FFFFFF",
        relief=tk.FLAT,
        command=lambda: self.authenticate("REGISTER"),
        padx=10,
        pady=8,
    ).pack(side=tk.RIGHT, padx=5)

    tk.Button(
        self.root,
        text="Back",
        font=("Helvetica", 10),
        bg="#E0E0E0",
        relief=tk.FLAT,
        command=self.show_home_screen,
    ).pack(pady=5)

  def start_host(self, ip):
    name = self.host_name_entry.get().strip()
    pwd = self.host_pass_entry.get().strip()
    if not name or not pwd:
      messagebox.showerror("Error", "Please fill in username and password!")
      return

    USER_DATABASE[name] = pwd
    self.my_name = name
    self.running = True

    try:
      self.server_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
      self.server_sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
      self.server_sock.bind((ip, 55555))
      self.server_sock.listen(1)
    except Exception as e:
      messagebox.showerror("Host Error", f"Could not start host: {e}")
      return

    self.show_chat_screen()
    self.append_chat(f"🐾 [System]: Hosting litter box on {ip}:55555.")
    self.trigger_welcome_bot()
    threading.Thread(target=self.accept_client, daemon=True).start()

  def accept_client(self):
    try:
      self.client_sock, addr = self.server_sock.accept()
      auth_data = self.client_sock.recv(1024).decode("utf-8")
      parts = auth_data.split("::")
      action, user, pwd = parts[0], parts[1], parts[2]

      if action == "REGISTER":
        if user in USER_DATABASE:
          self.client_sock.send("FAIL::Username already taken!".encode("utf-8"))
          self.client_sock.close()
          return
        else:
          USER_DATABASE[user] = pwd
          self.client_sock.send("SUCCESS::Welcome!".encode("utf-8"))
      elif action == "LOGIN":
        if user not in USER_DATABASE or USER_DATABASE[user] != pwd:
          self.client_sock.send(
              "FAIL::Invalid username or password!".encode("utf-8")
          )
          self.client_sock.close()
          return
        else:
          self.client_sock.send("SUCCESS::Welcome back!".encode("utf-8"))

      self.sock = self.client_sock
      self.append_chat(f"🐾 [System]: {user} logged in from {addr[0]}! 🐟")
      self.trigger_welcome_bot()
      threading.Thread(target=self.receive_loop, daemon=True).start()
    except Exception as e:
      print(e)

  def authenticate(self, action):
    ip = self.ip_entry.get().strip()
    name = self.join_name_entry.get().strip()
    pwd = self.join_pass_entry.get().strip()

    if not ip or not name or not pwd:
      messagebox.showerror("Error", "All fields are required!")
      return

    self.my_name = name
    self.running = True

    try:
      temp_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
      temp_sock.connect((ip, 55555))
      temp_sock.send(f"{action}::{name}::{pwd}".encode("utf-8"))
      response = temp_sock.recv(1024).decode("utf-8")

      status, message = response.split("::", 1)

      if status == "SUCCESS":
        self.sock = temp_sock
        self.show_chat_screen()
        self.append_chat(
            "🐾 [System]: Logged in successfully to your friend room! 🐟"
        )
        self.trigger_welcome_bot()
        threading.Thread(target=self.receive_loop, daemon=True).start()
      else:
        messagebox.showerror("Auth Failed", message)
        temp_sock.close()
    except Exception as e:
      messagebox.showerror("Connection Error", f"Could not connect: {e}")

  def trigger_welcome_bot(self):
    def send_welcome_sequence():
      time.sleep(1.0)
      self.append_chat("😺 CatChat - Welcome!: Welcome to the world of catchat!")

    threading.Thread(target=send_welcome_sequence, daemon=True).start()

  def show_chat_screen(self):
    self.clear_window()

    top_frame = tk.Frame(self.root, bg="#FFF0F5")
    top_frame.pack(fill=tk.X, padx=15, pady=10)

    tk.Label(
        top_frame,
        text=f"🐾 Active Room ({self.my_name})",
        font=("Helvetica", 14, "bold"),
        bg="#FFF0F5",
        fg="#D87093",
    ).pack(side=tk.LEFT)
    tk.Button(
        top_frame,
        text="Leave Room 🚪",
        font=("Helvetica", 10, "bold"),
        bg="#E0E0E0",
        fg="#333333",
        relief=tk.FLAT,
        command=self.show_home_screen,
        padx=8,
        pady=4,
    ).pack(side=tk.RIGHT)

    self.chat_display = scrolledtext.ScrolledText(
        self.root, wrap=tk.WORD, font=("Helvetica", 11), bg="#FFFFFF", fg="#333333"
    )
    self.chat_display.pack(padx=15, pady=5, fill=tk.BOTH, expand=True)
    self.chat_display.config(state=tk.DISABLED)

    input_frame = tk.Frame(self.root, bg="#FFF0F5")
    input_frame.pack(padx=15, pady=15, fill=tk.X)

    self.msg_entry = tk.Entry(
        input_frame, font=("Helvetica", 12), relief=tk.FLAT, bg="#FFFFFF"
    )
    self.msg_entry.pack(side=tk.LEFT, fill=tk.X, expand=True, ipady=8, padx=(0, 8))
    self.msg_entry.bind("<Return>", self.send_msg)

    tk.Button(
        input_frame,
        text="Send 🐟",
        font=("Helvetica", 11, "bold"),
        bg="#FFB6C1",
        fg="#FFFFFF",
        relief=tk.FLAT,
        command=self.send_msg,
    ).pack(side=tk.RIGHT)

  def disconnect_socket(self):
    self.running = False
    try:
      if self.sock:
        self.sock.close()
    except:
      pass
    try:
      if self.server_sock:
        self.server_sock.close()
    except:
      pass
    self.sock = None
    self.server_sock = None

  def append_chat(self, text):
    try:
      self.chat_display.config(state=tk.NORMAL)
      self.chat_display.insert(tk.END, text + "\n")
      self.chat_display.config(state=tk.DISABLED)
      self.chat_display.see(tk.END)
    except:
      pass

  def receive_loop(self):
    while self.running and self.sock:
      try:
        data = self.sock.recv(1024).decode("utf-8")
        if not data:
          break
        self.append_chat(data)
      except:
        break
    if self.running:
      self.append_chat("🐾 [System]: Connection closed.")

  def send_msg(self, event=None):
    msg = self.msg_entry.get().strip()
    if not msg:
      return
    formatted = f"🐱 {self.my_name}: {msg}"

    # Always show our own message in our own white box immediately
    self.append_chat(formatted)
    self.msg_entry.delete(0, tk.END)

    # Send over socket if connected
    if self.sock:
      try:
        self.sock.send(formatted.encode("utf-8"))
      except:
        self.append_chat("🐾 [System]: Failed to send message to peer.")


if __name__ == "__main__":
  root = tk.Tk()
  app = CatChatApp(root)
  root.mainloop()